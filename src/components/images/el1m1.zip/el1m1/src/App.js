import { Suspense, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import MULTYI from "./MULTYI";
import Duende_Island1 from "./Duende_Island1";
import "./styles.css";

function App() {
  const [action, setAction] = useState("IDLE");
  return (
    <>
      <Canvas camera={{ position: [0, 1, 2] }}>
        <ambientLight />
        <pointLight intensity={1} position={[-1, 1, 3]} color="white" />
        <pointLight intensity={1} position={[1, 1, 3]} color="white" />
        <pointLight intensity={1} position={[0, 3, -10]} color="white" />

        <Suspense fallback={null}>
          <MULTYI action={action} />
        </Suspense>
        <Suspense fallback={null}>
           <Duende_Island1 />
        </Suspense>
        <OrbitControls target={[0, 1, 0]} autoRotate />
      </Canvas>
      <div className="controls">
        

        <button onClick={() => setAction("SWING")}>SWING</button>
        <button onClick={() => setAction("IDLE")}>IDLE</button>
      </div>
    </>
    
    
  );
  
  
  }
  

export default App;
