

import React, { useRef } from 'react'
import { Canvas } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";

export default function Model({ ...props }) {
  const group = useRef()
  const { nodes, materials } = useGLTF('/Duende_Island1.gltf')
  return (
    <group ref={group} {...props} dispose={null}>
      <mesh geometry={nodes.Bakery_shop.geometry} material={materials.buildings1} position={[94.25, -1.69, -279.73]} />
      <mesh geometry={nodes.Bank.geometry} material={materials.buildings3} position={[52.31, -0.88, 303.35]} />
      <mesh geometry={nodes.Bar2.geometry} material={materials.buildings2} position={[-41.02, -1.59, -245.74]} />
      <mesh geometry={nodes.Barber_Shop1.geometry} material={materials.buildings2} position={[-35.96, -2.4, -111.08]} />
      <mesh geometry={nodes.Bridge.geometry} material={materials.Bridge} position={[-23.42, -6.38, -12.21]} />
      <mesh geometry={nodes.Cafe.geometry} material={materials.buildings2} position={[-56.07, -1.83, -134.07]} />
      <mesh geometry={nodes.Cake_park.geometry} material={materials.buildings1} position={[-87.24, -1.64, -260.75]} />
      <mesh geometry={nodes.Clouds.geometry} material={materials.Clouds} position={[27.2, 178.63, -15.35]} />
      <mesh geometry={nodes.Cup_cake_shop.geometry} material={materials.buildings1} position={[86.97, -1.7, -191.87]} />
      <mesh geometry={nodes.Elf_Office1.geometry} material={materials.buildings3} position={[116.75, -0.99, 249.7]} />
      <mesh geometry={nodes.Gas1.geometry} material={materials.Building5} position={[16.21, -1.64, 136.69]} />
      <mesh geometry={nodes.Grocery_store1.geometry} material={materials.buildings4} position={[2.66, -0.89, 235.78]} />
      <mesh geometry={nodes.Gymn1.geometry} material={materials.buildings2} position={[-27.88, -1.67, -314.56]} />
      <mesh geometry={nodes.Helipad.geometry} material={materials.Lanscape} position={[-77.86, -0.87, 393.13]} />
      <mesh geometry={nodes.Hospital1.geometry} material={materials.buildings2} position={[-4.78, -1.61, -321.33]} />
      <mesh geometry={nodes.House.geometry} material={materials.buildings1} position={[-91.32, -1.45, -331.86]} />
      <mesh geometry={nodes.House1.geometry} material={materials.buildings4} position={[-55.11, -0.93, 287.98]} />
      <mesh geometry={nodes.Island_1.geometry} material={materials.Lanscape} position={[5.48, -63.64, -248.03]} />
      <mesh geometry={nodes.Island_2.geometry} material={materials.Lanscape} position={[24.99, -0.89, 217.75]} />
      <group position={[16.49, -1.06, -150.75]}>
        <mesh geometry={nodes.Scene1854.geometry} material={materials.Clouds} />
        <mesh geometry={nodes.Scene1854_1.geometry} material={materials.Lanscape} />
      </group>
      <mesh geometry={nodes.Mountain1.geometry} material={materials.Lanscape} position={[-105.33, 19.23, -116.37]} />
      <mesh geometry={nodes.Mountain2.geometry} material={materials.Lanscape} position={[140.34, 17.96, 98.02]} />
      <mesh geometry={nodes.Mushroom_Orange.geometry} material={materials.Lanscape} position={[-55.92, 4.19, -185.86]} />
      <mesh geometry={nodes.Mushroom_Purple.geometry} material={materials.Lanscape} position={[19.1, 0.07, -170.21]} />
      <mesh geometry={nodes.Office1.geometry} material={materials.buildings4} position={[88.59, -1.13, 282.62]} />
      <mesh geometry={nodes.Path.geometry} material={materials.Lanscape} position={[-15.86, -0.38, -204.8]} />
      <mesh geometry={nodes.Path001.geometry} material={materials.Lanscape} position={[-15.86, 0.08, 191.52]} />
      <mesh geometry={nodes.Purple_Flower.geometry} material={materials.Lanscape} position={[4.69, 1.27, -235.09]} />
      <mesh geometry={nodes.Restaurant3.geometry} material={materials.buildings2} position={[113.86, -1.82, -261.87]} />
      <mesh geometry={nodes.Rocks.geometry} material={materials.Lanscape} position={[-1.45, 3.17, -211.45]} />
      <mesh geometry={nodes.Rocks001.geometry} material={materials.Lanscape} position={[16.57, 3.17, 206.09]} />
      <mesh geometry={nodes.School.geometry} material={materials.buildings4} position={[89.43, -1.21, 165.9]} />
      <mesh geometry={nodes.Shoping_store1.geometry} material={materials.buildings3} position={[-72.97, -1.05, 151.07]} />
      <mesh geometry={nodes.Store1.geometry} material={materials.buildings3} position={[-45.25, -0.89, 207.47]} />
      <mesh geometry={nodes.Sunflower.geometry} material={materials.Lanscape} position={[14.06, -1.79, -94.04]} />
      <mesh geometry={nodes.Telephone.geometry} material={materials.buildings3} position={[-84.6, -0.99, 251.1]} />
      <mesh geometry={nodes.Transaction_Path.geometry} material={materials.Lanscape} position={[-15.86, 0.18, 191.52]} />
      <mesh geometry={nodes.Tree1.geometry} material={materials.Lanscape} position={[-20.35, 14.48, -198.89]} />
      <mesh geometry={nodes.Tree1001.geometry} material={materials.Lanscape} position={[33.06, 14.48, 261.83]} />
      <mesh geometry={nodes.Tree2.geometry} material={materials.Lanscape} position={[62.75, 14.34, -286.26]} />
      <mesh geometry={nodes.Tree2001.geometry} material={materials.Lanscape} position={[33.88, 14.34, 366.87]} />
    </group>
  )
  
}


useGLTF.preload('/Duende_Island1.gltf')
function usePrevious(value) {
  // The ref object is a generic container whose current property is mutable ...
  // ... and can hold any value, similar to an instance property on a class
  const ref = useRef();
  // Store current value in ref
  useEffect(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes
  // Return previous value (happens before update in useEffect above)
  return ref.current;
}
 